from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import asyncio
import json
from pathlib import Path
from typing import List, Dict
import subprocess
import os
from datetime import datetime

app = FastAPI(title="Hybrid Code Intelligence Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

from engines.sast_engine import run_semgrep_analysis
from engines.governance_engine import run_governance_check
from engines.dast_engine import run_runtime_analysis

@app.get("/")
async def root():
    return {"status": "Hybrid Code Intelligence Agent Running"}

@app.post("/scan")
async def scan_code(request: dict):
    """
    Endpoint to trigger code scan - ALWAYS reads fresh file content
    """
    file_path = request.get("file_path", "test_code.py")
    
    # Normalize path - remove leading slashes, handle both absolute and relative
    if file_path.startswith('/'):
        file_path = file_path[1:]
    
    # Try multiple path variations
    possible_paths = [
        file_path,
        os.path.join("test_files", os.path.basename(file_path)),
        os.path.join("..", file_path),
        os.path.abspath(file_path)
    ]
    
    actual_path = None
    for path in possible_paths:
        if os.path.exists(path):
            actual_path = path
            break
    
    if not actual_path:
        return JSONResponse(
            status_code=404,
            content={
                "error": f"File not found: {file_path}",
                "tried_paths": possible_paths
            }
        )
    
    results = {
        "timestamp": datetime.now().isoformat(),
        "file": actual_path,
        "engines": {}
    }
    
    # Run parallel analysis - each engine reads file fresh
    sast_task = asyncio.create_task(run_semgrep_analysis(actual_path))
    governance_task = asyncio.create_task(run_governance_check(actual_path))
    dast_task = asyncio.create_task(run_runtime_analysis(actual_path))
    
    sast_results, governance_results, dast_results = await asyncio.gather(
        sast_task, governance_task, dast_task
    )
    
    results["engines"]["sast"] = sast_results
    results["engines"]["governance"] = governance_results
    results["engines"]["dast"] = dast_results
    
    # Calculate verdict
    verdict = calculate_verdict(results)
    results["verdict"] = verdict
    
    # Broadcast to WebSocket clients
    await manager.broadcast({
        "type": "scan_complete",
        "data": results
    })
    
    return JSONResponse(content=results)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({"status": "received", "data": data})
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.post("/add-suggestion-comment")
async def add_suggestion_comment(request: dict):
    """
    Add AI suggestion as comment above the line
    """
    file_path = request.get("file_path")
    line_num = request.get("line")
    suggestion = request.get("suggestion")
    
    # Normalize path
    if file_path.startswith('/'):
        file_path = file_path[1:]
    
    possible_paths = [
        file_path,
        os.path.join("test_files", os.path.basename(file_path)),
        os.path.join("..", file_path)
    ]
    
    actual_path = None
    for path in possible_paths:
        if os.path.exists(path):
            actual_path = path
            break
    
    if not actual_path:
        return {"status": "error", "message": f"File not found: {file_path}"}
    
    try:
        # Read file with proper encoding
        with open(actual_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        if 0 < line_num <= len(lines):
            # Get indentation from the target line
            target_line = lines[line_num - 1]
            indent = len(target_line) - len(target_line.lstrip())
            
            # Create comment with same indentation
            comment = ' ' * indent + f"# AI Suggestion: {suggestion}\n"
            
            # Insert comment above the line
            lines.insert(line_num - 1, comment)
            
            # Write back to file
            with open(actual_path, 'w', encoding='utf-8') as f:
                f.writelines(lines)
            
            print(f"✅ Added suggestion comment to {actual_path} at line {line_num}")
            
            return {
                "status": "success", 
                "message": f"Suggestion added at line {line_num}",
                "file": actual_path
            }
        else:
            return {"status": "error", "message": f"Line {line_num} out of range (file has {len(lines)} lines)"}
    except Exception as e:
        print(f"❌ Error adding suggestion: {e}")
        return {"status": "error", "message": str(e)}

@app.post("/apply-fix")
async def apply_fix(request: dict):
    """
    Apply auto-remediation to code - supports both single line and batch fixes
    """
    file_path = request.get("file_path")
    
    if "line" in request and "new_code" in request:
        return await apply_single_line_fix(file_path, request)
    else:
        return await apply_batch_fixes(file_path, request.get("fixes", []))

async def apply_single_line_fix(file_path: str, fix_data: dict):
    """
    Apply a single line fix by replacing exact line
    """
    line_num = fix_data.get("line")
    new_code = fix_data.get("new_code", "")
    
    # Normalize path
    if file_path.startswith('/'):
        file_path = file_path[1:]
    
    possible_paths = [
        file_path,
        os.path.join("test_files", os.path.basename(file_path)),
        os.path.join("..", file_path)
    ]
    
    actual_path = None
    for path in possible_paths:
        if os.path.exists(path):
            actual_path = path
            break
    
    if not actual_path:
        return {"status": "error", "message": f"File not found: {file_path}"}
    
    try:
        # Read file with proper encoding
        with open(actual_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        if 0 < line_num <= len(lines):
            # Get original line for indentation
            original_line = lines[line_num - 1]
            indent = len(original_line) - len(original_line.lstrip())
            
            # Apply new code with proper indentation
            if new_code.strip():
                # Add indentation and newline
                fixed_line = ' ' * indent + new_code.strip() + '\n'
                lines[line_num - 1] = fixed_line
                
                # Write back to file
                with open(actual_path, 'w', encoding='utf-8') as f:
                    f.writelines(lines)
                
                print(f"✅ Applied fix to {actual_path} at line {line_num}")
                print(f"   Old: {original_line.strip()}")
                print(f"   New: {fixed_line.strip()}")
                
                return {
                    "status": "success",
                    "message": f"Applied fix to line {line_num}",
                    "line": line_num,
                    "file": actual_path
                }
            else:
                return {"status": "error", "message": "New code is empty"}
        else:
            return {
                "status": "error", 
                "message": f"Line {line_num} out of range (file has {len(lines)} lines)"
            }
            
    except Exception as e:
        print(f"❌ Error applying fix: {e}")
        import traceback
        traceback.print_exc()
        return {"status": "error", "message": str(e)}

async def apply_batch_fixes(file_path: str, fixes: list):
    """
    Apply multiple fixes as TODO comments
    """
    try:
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        applied_count = 0
        for fix in fixes:
            if fix.get("suggestion") and fix.get("line"):
                line_num = fix.get("line") - 1
                if 0 <= line_num < len(lines):
                    suggestion = fix.get("suggestion")
                    lines[line_num] = f"# TODO: {suggestion}\n{lines[line_num]}"
                    applied_count += 1
        
        with open(file_path, 'w') as f:
            f.writelines(lines)
        
        return {
            "status": "success", 
            "message": f"Applied {applied_count} fix suggestions",
            "fixes_applied": applied_count
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/critical-alert")
async def critical_alert(request: dict):
    """
    Notify frontend of critical issues found during auto-scan
    """
    await manager.broadcast({
        "type": "critical_alert",
        "data": request
    })
    return {"status": "broadcast"}

def calculate_verdict(results: dict) -> dict:
    """
    Calculate overall verdict based on engine results
    """
    critical_count = 0
    high_count = 0
    
    for engine_name, engine_data in results["engines"].items():
        if engine_data.get("status") == "error":
            critical_count += 1
        elif engine_data.get("status") == "warning":
            high_count += 1
    
    if critical_count > 0:
        return {
            "decision": "BLOCK",
            "severity": "CRITICAL",
            "reason": f"Found {critical_count} critical issues"
        }
    elif high_count > 0:
        return {
            "decision": "WARN",
            "severity": "HIGH",
            "reason": f"Found {high_count} high-priority warnings"
        }
    else:
        return {
            "decision": "APPROVE",
            "severity": "NONE",
            "reason": "All checks passed"
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)