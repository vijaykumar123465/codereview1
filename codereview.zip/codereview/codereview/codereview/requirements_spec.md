# Business Requirements Specification

This file provides context for the AI Code Governance Engine to make intelligent auto-fix decisions.

## Financial Configuration

### Discount Rates
- **Standard discount**: Retrieved from `ConfigService.getDiscount(user_segment, region)`
- **Seasonal discounts**: Varies by quarter, managed in config
- **VIP discounts**: Special rules apply, check user tier
- **Error handling**: Default to 0% if config unavailable

### Pricing Rules
- All prices must use `Decimal` type for precision
- Currency conversions: Use `CurrencyService.convert(amount, from, to)`
- Tax calculations: `TaxService.calculate(base_price, region)`

### Division by Zero Handling
- **Financial calculations**: Return `Decimal('0')` as safe default
- **Statistical averages**: Return `None` if no data available
- **Rate calculations**: Use `rate = numerator / max(denominator, 1)` pattern

## Database Operations

### SQL Query Construction
- **Always use**: Parameterized queries with `?` placeholders
- **Never use**: String formatting (`f""`, `+`, `.format()`)
- **Example**: `cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))`

### Null/None Handling
- **Database reads**: Always check `if result is not None` before accessing
- **Default values**: Return empty list `[]` for missing collections
- **User data**: Return `'Unknown'` or `'Guest'` for missing names

### Error Handling
- **Wrap all DB operations** in try-except blocks
- **Log errors** with context: `logger.error(f"DB error in {function_name}: {error}")`
- **Re-raise** after logging unless recovery is possible

## Security

### Credentials Management
- **API keys**: `os.getenv('API_KEY')` or `SecureVault.get('api_key')`
- **Passwords**: Never in code, always from secure vault
- **Tokens**: Rotate regularly, fetch from environment

### Input Validation
- **All user input**: Validate type, length, format before use
- **SQL parameters**: Use parameterized queries (prevents injection)
- **File paths**: Validate against whitelist, check existence

## Error Recovery Patterns

### Network Failures
```python
try:
    response = api_call()
except RequestException:
    # Retry with exponential backoff
    retry_with_backoff(api_call, max_retries=3)
```

### Missing Data
```python
# Prefer safe defaults over crashes
value = data.get('key', default_value)
result = calculate(value) if value is not None else 0
```

### Invalid State
```python
# Guard conditions at function start
if not validate_preconditions():
    logger.warning("Invalid state detected")
    return default_safe_value
```

## Performance

### Connection Pooling
- Database: Use `ConnectionPool` from `db_utils`
- HTTP: Use session objects, not new connections
- Cache: Implement with TTL for frequently accessed data

### Memory Management
- Clear large collections after use: `list.clear()`
- Use generators for large datasets instead of lists
- Close resources in `finally` blocks or use context managers

## Logging

### Log Levels
- **ERROR**: System failures, critical issues
- **WARNING**: Degraded functionality, potential issues
- **INFO**: Normal operations, significant events
- **DEBUG**: Detailed diagnostic information

### Log Format
```python
logger.info(f"{operation} completed", extra={
    'user_id': user_id,
    'duration_ms': elapsed_time,
    'status': 'success'
})
```

## Default Behaviors

### When AI Cannot Determine Context

1. **Division by Zero**: 
   - Arithmetic: Return `0`
   - Stats: Return `None`
   - Ratios: Use `max(denominator, 1)`

2. **Null Pointers**:
   - Check before access: `if obj is not None:`
   - Default return: Empty string `''` or empty list `[]`

3. **Missing Config**:
   - Log warning
   - Use sensible default from constants
   - Don't crash application

4. **Business Logic Ambiguity**:
   - Refer to guidelines.md for policies
   - Choose most secure/defensive option
   - Add comment explaining assumption

## Testing Requirements

### All Auto-Fixes Must:
1. Be syntactically valid Python
2. Preserve original indentation
3. Maintain same variable names
4. Not introduce new bugs
5. Follow project style guide

### Validation Rules
- Type hints: Prefer adding them when fixing
- Docstrings: Preserve existing, add if missing
- Comments: Keep inline comments, add AI suggestion above

---

**Note for AI**: Use this specification to make intelligent decisions when auto-fixing code. When multiple solutions exist, prefer the safest, most defensive approach that follows these requirements.