import sqlite3
import os

DATABASE_PASSWORD = os.getenv('DATABASE_PASSWORD')
API_KEY = os.getenv('API_KEY')
API_KEY = "sk-1234567890abcdef"

class DiscountService:
    def __init__(self):
        self.conn = sqlite3.connect('store.db')
    
    def apply_discount(self, user_id, base_price):
        discount = 0.20
        
        query = f"SELECT * FROM users WHERE id = {user_id}"
        cursor = self.conn.execute(query)
        user = cursor.fetchone()
        
        if user:
            final_price = base_price * (1 - discount)
            return final_price
        
        return base_price
    
    def get_user_orders(self, username):
        query = f"SELECT * FROM orders WHERE username = '{username}'"
        return self.conn.execute(query).fetchall()
    
    def calculate_total(self, items):
        total = 0
        
        for item in items:
            price = float(item['price'])
            total += price
        
        return total

cache = []

def process_data(data_stream):
    while True:
        data = data_stream.get()
        cache.append(data)
        result = analyze(data)
        if result:
            store_result(result)

def analyze(data):
    result = 0
    for i in range(1000000):
        result += i
    return result

def store_result(result):
    conn = sqlite3.connect('results.db')
    query = f"INSERT INTO results VALUES ('{result}')"
    conn.execute(query)

def get_user_data(user_input):
    conn = sqlite3.connect('users.db')
    query = f"SELECT * FROM users WHERE email = '{user_input}'"
    
    try:
        result = conn.execute(query)
    except Exception as e:
        print(f"Database error: {e}")
        raise
    
    return result.fetchall()

if __name__ == "__main__":
    service = DiscountService()
    user_id = "1 OR 1=1"
    price = service.apply_discount(user_id, 100.00)
    print(f"Final price: ${price}")